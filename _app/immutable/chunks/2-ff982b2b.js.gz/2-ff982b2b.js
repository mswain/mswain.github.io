import{default as t}from"../components/pages/_page.svelte-84041f18.js";export{t as component};
