import{default as t}from"../components/error.svelte-03b3ffcb.js";export{t as component};
